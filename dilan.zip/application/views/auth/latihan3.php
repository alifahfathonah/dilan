<?php

$anak = "anak";
    while($anak <= 10){
           echo $anak."<br/>";  
    }
